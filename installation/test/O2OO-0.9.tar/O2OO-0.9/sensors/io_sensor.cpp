#include <map>
#include <string>
#include <vector>

#include "../error.h"
#include "../byte_array.h"
#include "../terminal.h"
#include "../IO_Device.h"
#include "sensor.h"
#include "io_sensor.h"

io_sensor::io_sensor()
{
}

io_sensor::~io_sensor()
{
}
