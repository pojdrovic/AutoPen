class OBD2;

class io_sensor : public sensor
{
public:
	io_sensor();
	virtual ~io_sensor();
};
