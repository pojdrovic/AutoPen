// SVN: $Revision: 442 $
void error_exit(const char *format, ...);
