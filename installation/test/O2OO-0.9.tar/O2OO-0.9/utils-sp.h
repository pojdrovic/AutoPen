void retrieve_metadata(sqlite3 *db, std::string sensor, std::string *units, double *mi, double *ma, std::string *str);
void find_data_bw(sqlite3 *db, std::string sensor, double *mi, double *ma);
