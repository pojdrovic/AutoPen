extern unsigned char logo[];
extern int logo_size;
