void emit_kml(sqlite3 *db, std::string sensor, std::string parameters);
