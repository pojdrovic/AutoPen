void emit_xml(sqlite3 *db, std::string sensor, std::string parameters);
