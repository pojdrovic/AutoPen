// SVN: $Revision: 442 $
void emulate_obd2(terminal *t, byte_array *command, std::vector<byte_array *> *results);
