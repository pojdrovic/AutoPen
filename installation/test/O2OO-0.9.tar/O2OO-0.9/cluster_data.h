std::vector<double> * split_value_list(std::vector<double> *values_in, int n);
